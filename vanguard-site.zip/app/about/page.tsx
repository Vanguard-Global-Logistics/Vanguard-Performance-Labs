import { SectionHeading, GlassCard, GlowButton, DisclaimerBanner } from "@/components/ui";
import { DISCLAIMER } from "@/lib/content";

export const metadata = { title: "About Vanguard" };

export default function Page() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <SectionHeading kicker="Our Company" title="About Vanguard" sub="Veteran-owned biotechnology, education, AI software, and research — built to become the most trusted name in the space." />
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <GlassCard className="p-5"><div className="font-display font-bold text-bone">Mission</div><p className="mt-2 text-sm text-muted">Give people the truth about peptide science and the tools clinics need to run smarter.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Veteran-Owned</div><p className="mt-2 text-sm text-muted">Founded and run on discipline, integrity, and looking out for the people we serve.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Education First</div><p className="mt-2 text-sm text-muted">We lead with honest, evidence-graded education — never hype.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Innovation</div><p className="mt-2 text-sm text-muted">AI-powered software that puts world-class operations within reach of every clinic.</p></GlassCard>
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <GlowButton href="/contact">Get in touch</GlowButton>
        <GlowButton href="/peptastic" variant="secondary">See Peptastic</GlowButton>
      </div>
      <div className="mt-8"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
