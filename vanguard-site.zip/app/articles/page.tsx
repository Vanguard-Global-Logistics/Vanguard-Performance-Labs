import { SectionHeading, GlassCard, GlowButton, DisclaimerBanner } from "@/components/ui";
import { DISCLAIMER } from "@/lib/content";

export const metadata = { title: "Articles" };

export default function Page() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <SectionHeading kicker="Insights" title="Articles" sub="Educational articles, clinical discussions, and business insights from the Vanguard team." />
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <GlassCard className="p-5"><div className="font-display font-bold text-bone">The Honest Guide to Peptide Evidence</div><p className="mt-2 text-sm text-muted">Why evidence grading matters more than marketing claims.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">What Clinic Owners Miss About AI</div><p className="mt-2 text-sm text-muted">Where AI actually saves clinics time and money.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Reading a COA</div><p className="mt-2 text-sm text-muted">How to evaluate certificates of analysis and documentation.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Regulatory Watch</div><p className="mt-2 text-sm text-muted">Plain-English updates on the shifting peptide landscape.</p></GlassCard>
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <GlowButton href="/contact">Get in touch</GlowButton>
        <GlowButton href="/peptastic" variant="secondary">See Peptastic</GlowButton>
      </div>
      <div className="mt-8"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
