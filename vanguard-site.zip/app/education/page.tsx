"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { COMPOUNDS, DISCLAIMER } from "@/lib/content";
import { GlassCard, SectionHeading, EvidenceTag, DisclaimerBanner } from "@/components/ui";
import type { EvidenceLevel } from "@/types";

export default function EducationPage() {
  const [q, setQ] = useState("");
  const [f, setF] = useState<"all" | EvidenceLevel>("all");
  const list = useMemo(
    () =>
      COMPOUNDS.filter((c) => {
        const qm = !q || c.name.toLowerCase().includes(q.toLowerCase()) || c.category.toLowerCase().includes(q.toLowerCase());
        const fm = f === "all" || c.evidence === f;
        return qm && fm;
      }),
    [q, f]
  );
  const filters: ("all" | EvidenceLevel)[] = ["all", "strong", "moderate", "limited"];
  return (
    <div className="mx-auto max-w-7xl px-4 py-16">
      <SectionHeading kicker="Peptide Education Library" title="What the Science Actually Says"
        sub="Educational overviews with honest evidence grading. No hype, no treatment advice." />
      <div className="mx-auto mt-8 max-w-2xl">
        <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-4">
          <Search size={16} className="text-muted" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search compounds…"
            className="w-full bg-transparent py-3 text-sm text-bone outline-none placeholder:text-muted" />
        </div>
        <div className="mt-3 flex gap-2">
          {filters.map((x) => (
            <button key={x} onClick={() => setF(x)}
              className={`flex-1 rounded-full border px-3 py-1.5 text-xs font-semibold capitalize transition ${
                f === x ? "border-vanguard-cyan bg-vanguard-cyan/15 text-vanguard-cyan" : "border-white/10 text-muted hover:text-bone"
              }`}>{x}</button>
          ))}
        </div>
      </div>

      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((c) => (
          <Link key={c.slug} href={`/education/${c.slug}`}>
            <GlassCard className="h-full p-5 transition hover:border-vanguard-cyan/40">
              <div className="flex items-center justify-between">
                <div className="font-display text-lg font-bold text-bone">{c.name}</div>
                <span className="rounded-full border border-vanguard-cyan/40 bg-vanguard-cyan/10 px-2 py-0.5 text-[10px] font-semibold text-vanguard-cyan">{c.category}</span>
              </div>
              <p className="mt-2 line-clamp-3 text-sm text-muted">{c.overview}</p>
              <div className="mt-4"><EvidenceTag level={c.evidence} /></div>
            </GlassCard>
          </Link>
        ))}
        {list.length === 0 && <p className="col-span-full py-10 text-center text-muted">No results — try another search.</p>}
      </div>

      <div className="mx-auto mt-12 max-w-3xl"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
