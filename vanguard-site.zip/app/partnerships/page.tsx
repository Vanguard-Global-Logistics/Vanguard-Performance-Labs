import { SectionHeading, GlassCard, GlowButton, DisclaimerBanner } from "@/components/ui";
import { DISCLAIMER } from "@/lib/content";

export const metadata = { title: "Partnerships" };

export default function Page() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <SectionHeading kicker="Work With Us" title="Partnerships" sub="Clinics, researchers, universities, labs, and strategic partners — build with Vanguard." />
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <GlassCard className="p-5"><div className="font-display font-bold text-bone">Clinical Partners</div><p className="mt-2 text-sm text-muted">Bring Peptastic and Vanguard education to your practice.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Research & Academia</div><p className="mt-2 text-sm text-muted">Collaborate on educational content and research.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Strategic Partnerships</div><p className="mt-2 text-sm text-muted">Integrations, distribution, and co-marketing.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Become a Partner</div><p className="mt-2 text-sm text-muted">Tell us what you have in mind and we will route you.</p></GlassCard>
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <GlowButton href="/contact">Get in touch</GlowButton>
        <GlowButton href="/peptastic" variant="secondary">See Peptastic</GlowButton>
      </div>
      <div className="mt-8"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
