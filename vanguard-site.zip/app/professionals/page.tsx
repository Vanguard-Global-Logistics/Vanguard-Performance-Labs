import { SectionHeading, GlassCard, GlowButton, DisclaimerBanner } from "@/components/ui";
import { DISCLAIMER } from "@/lib/content";

export const metadata = { title: "Medical Professionals" };

export default function Page() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <SectionHeading kicker="For Clinicians" title="Medical Professionals" sub="Resources, education, and Peptastic tooling built for licensed providers and clinical teams." />
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <GlassCard className="p-5"><div className="font-display font-bold text-bone">Clinical Resources</div><p className="mt-2 text-sm text-muted">Evidence-graded references for professional education.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Peptastic for Clinics</div><p className="mt-2 text-sm text-muted">Run scheduling, CRM, inventory, and reporting in one place.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Provider Onboarding</div><p className="mt-2 text-sm text-muted">Fast staff training and knowledge capture.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Request Access</div><p className="mt-2 text-sm text-muted">Get a professional walkthrough and demo.</p></GlassCard>
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <GlowButton href="/contact">Get in touch</GlowButton>
        <GlowButton href="/peptastic" variant="secondary">See Peptastic</GlowButton>
      </div>
      <div className="mt-8"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
