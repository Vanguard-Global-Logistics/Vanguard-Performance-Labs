import { SectionHeading, GlassCard, GlowButton, DisclaimerBanner } from "@/components/ui";
import { DISCLAIMER } from "@/lib/content";

export const metadata = { title: "Scientific Research" };

export default function Page() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <SectionHeading kicker="Research" title="Scientific Research" sub="Summaries, mechanisms, and references across the compounds we cover — presented as education." />
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <GlassCard className="p-5"><div className="font-display font-bold text-bone">Research Summaries</div><p className="mt-2 text-sm text-muted">Plain-language digests of what published studies show, with evidence grading.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Mechanisms</div><p className="mt-2 text-sm text-muted">How compounds are studied to work, at a level anyone can follow.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">References</div><p className="mt-2 text-sm text-muted">Source attribution verified by editorial review before publication.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Ongoing Updates</div><p className="mt-2 text-sm text-muted">The landscape changes fast — we track and update as research evolves.</p></GlassCard>
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <GlowButton href="/contact">Get in touch</GlowButton>
        <GlowButton href="/peptastic" variant="secondary">See Peptastic</GlowButton>
      </div>
      <div className="mt-8"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
