import type { MetadataRoute } from "next";
import { NAV, COMPOUNDS } from "@/lib/content";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://vanguardperformancelabs.com";
  const pages = NAV.map((n) => ({ url: `${base}${n.href}`, lastModified: new Date() }));
  const compounds = COMPOUNDS.map((c) => ({ url: `${base}/education/${c.slug}`, lastModified: new Date() }));
  return [...pages, ...compounds];
}
