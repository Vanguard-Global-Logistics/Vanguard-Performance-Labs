import { SectionHeading, GlassCard, GlowButton, DisclaimerBanner } from "@/components/ui";
import { DISCLAIMER } from "@/lib/content";

export const metadata = { title: "Video Library" };

export default function Page() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <SectionHeading kicker="Watch & Learn" title="Video Library" sub="Educational videos, explainers, and clinical discussions. New content added regularly." />
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <GlassCard className="p-5"><div className="font-display font-bold text-bone">Peptide Science 101</div><p className="mt-2 text-sm text-muted">Foundations, explained simply.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Peptastic Walkthrough</div><p className="mt-2 text-sm text-muted">A tour of the clinic operating system.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Evidence Explained</div><p className="mt-2 text-sm text-muted">What strong vs. limited evidence really means.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Founder Q&A</div><p className="mt-2 text-sm text-muted">The veteran story behind Vanguard.</p></GlassCard>
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <GlowButton href="/contact">Get in touch</GlowButton>
        <GlowButton href="/peptastic" variant="secondary">See Peptastic</GlowButton>
      </div>
      <div className="mt-8"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
