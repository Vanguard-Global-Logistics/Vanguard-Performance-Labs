import { SectionHeading, GlassCard, GlowButton, DisclaimerBanner } from "@/components/ui";
import { DISCLAIMER } from "@/lib/content";

export const metadata = { title: "Wholesale" };

export default function Page() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <SectionHeading kicker="For Buyers" title="Wholesale" sub="Professional and wholesale accounts with documentation, quotes, and purchase-order workflows." />
      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <GlassCard className="p-5"><div className="font-display font-bold text-bone">Apply for a Wholesale Account</div><p className="mt-2 text-sm text-muted">Business verification, tax/resale docs, and volume terms.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Request Wholesale Pricing</div><p className="mt-2 text-sm text-muted">Tiered pricing for qualified accounts.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Submit a Purchase Order</div><p className="mt-2 text-sm text-muted">PO workflow with document upload and team review.</p></GlassCard><GlassCard className="p-5"><div className="font-display font-bold text-bone">Documentation</div><p className="mt-2 text-sm text-muted">COAs and batch records for approved accounts.</p></GlassCard>
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <GlowButton href="/contact">Get in touch</GlowButton>
        <GlowButton href="/peptastic" variant="secondary">See Peptastic</GlowButton>
      </div>
      <div className="mt-8"><DisclaimerBanner text={DISCLAIMER} /></div>
    </div>
  );
}
