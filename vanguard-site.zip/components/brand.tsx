// Brand artwork built as SVG so the repo has ZERO missing/placeholder assets.
// These are swappable: replace with approved artwork later without layout changes.

// Cinematic hero centerpiece: gold winged research vial with glow ring.
// Swappable for approved artwork later; keeps the same footprint.
export function WingedVial({ className = "", size = 220, label = false }: { className?: string; size?: number; label?: boolean }) {
  return (
    <svg className={className} width={size} height={size * 0.75} viewBox="0 0 320 240" fill="none" aria-hidden>
      <defs>
        <linearGradient id="vgGold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#F6D98B" /><stop offset="45%" stopColor="#E8A93B" /><stop offset="100%" stopColor="#9C6B1E" />
        </linearGradient>
        <linearGradient id="vgVial" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#5A3B8C" /><stop offset="55%" stopColor="#3A2168" /><stop offset="100%" stopColor="#1C1140" />
        </linearGradient>
        <radialGradient id="vgRing" cx="0.5" cy="0.5" r="0.5">
          <stop offset="60%" stopColor="#E8A93B" stopOpacity="0" /><stop offset="82%" stopColor="#E8A93B" stopOpacity="0.55" /><stop offset="100%" stopColor="#E8A93B" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="vgHalo" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0.45" /><stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
        </radialGradient>
      </defs>
      <ellipse cx="160" cy="120" rx="150" ry="120" fill="url(#vgHalo)" />
      <circle cx="160" cy="118" r="92" fill="url(#vgRing)" />
      {/* wings */}
      {[-1, 1].map((s) => (
        <g key={s} transform={`translate(160,110) scale(${s},1)`}>
          {[0, 1, 2, 3, 4].map((i) => (
            <path key={i}
              d={`M8 ${-6 + i * 9} Q ${70 + i * 14} ${-18 + i * 9} ${120 + i * 12} ${4 + i * 11} Q ${74 + i * 10} ${2 + i * 9} 8 ${8 + i * 9} Z`}
              fill="url(#vgGold)" opacity={0.95 - i * 0.13} />
          ))}
        </g>
      ))}
      {/* vial body */}
      <rect x="132" y="72" width="56" height="120" rx="26" fill="url(#vgVial)" stroke="url(#vgGold)" strokeWidth="2" />
      <rect x="140" y="80" width="8" height="96" rx="4" fill="#ffffff" opacity="0.14" />
      {/* cap */}
      <rect x="138" y="58" width="44" height="20" rx="5" fill="#12101C" stroke="url(#vgGold)" strokeWidth="1.5" />
      {/* V emblem */}
      <path d="M148 104 L160 132 L172 104" stroke="url(#vgGold)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      {label && (
        <g>
          <rect x="132" y="150" width="56" height="30" rx="4" fill="#0E0B1A" opacity="0.85" />
          <text x="160" y="162" textAnchor="middle" fontSize="7" fontWeight="800" fill="#E8A93B" fontFamily="ui-sans-serif,sans-serif">ADVANCED FORMULA</text>
          <text x="160" y="173" textAnchor="middle" fontSize="6.5" fontWeight="700" fill="#B9A6E8" fontFamily="ui-sans-serif,sans-serif">RESEARCH PEPTIDE</text>
        </g>
      )}
    </svg>
  );
}

export function JessiePortrait({ className = "", size = 300 }: { className?: string; size?: number }) {
  return (
    <svg className={className} width={size} height={size * 1.25} viewBox="0 0 240 300" fill="none" aria-label="Jessie, Vanguard AI Concierge">
      <defs>
        <linearGradient id="jCoat" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#F4F7FF" /><stop offset="100%" stopColor="#C9D4EC" /></linearGradient>
        <linearGradient id="jRim" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#8B5CF6" /><stop offset="100%" stopColor="#3B6BFF" /></linearGradient>
        <radialGradient id="jGlow" cx="0.5" cy="0.4" r="0.6"><stop offset="0%" stopColor="#8B5CF6" stopOpacity="0.45" /><stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" /></radialGradient>
      </defs>
      <ellipse cx="120" cy="150" rx="110" ry="140" fill="url(#jGlow)" />
      {/* purple rim light */}
      <path d="M60 120 Q120 40 180 120 L180 300 L60 300 Z" fill="url(#jRim)" opacity="0.25" />
      {/* white coat */}
      <path d="M72 150 Q120 128 168 150 L182 300 L58 300 Z" fill="url(#jCoat)" />
      <path d="M120 138 L120 300" stroke="#AEB9D6" strokeWidth="1.5" />
      {/* crossed arms suggestion */}
      <path d="M72 200 Q120 176 168 200 L160 232 Q120 210 80 232 Z" fill="#DCE4F5" />
      {/* neck + head */}
      <rect x="108" y="112" width="24" height="26" rx="10" fill="#E7B58C" />
      <ellipse cx="120" cy="92" rx="34" ry="40" fill="#EEC29B" />
      {/* hair */}
      <path d="M86 92 Q88 46 120 44 Q152 46 154 92 Q150 70 120 66 Q90 70 86 92 Z" fill="#3A2E4A" />
      {/* eyes + smile */}
      <circle cx="108" cy="90" r="3" fill="#2A2340" /><circle cx="132" cy="90" r="3" fill="#2A2340" />
      <path d="M110 104 Q120 111 130 104" stroke="#B4745A" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      {/* rim highlight */}
      <path d="M154 92 Q160 130 150 160" stroke="url(#jRim)" strokeWidth="3" fill="none" opacity="0.7" />
    </svg>
  );
}

export function VanguardLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <span className="relative grid h-9 w-9 place-items-center overflow-hidden rounded-lg bg-vg-grad">
        <span className="absolute inset-0 bg-[radial-gradient(120%_120%_at_30%_20%,rgba(255,255,255,0.5),transparent_45%)]" />
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 4 L12 20 L21 4" stroke="#05070F" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
      </span>
      <span className="leading-none">
        <span className="block font-display text-base font-black tracking-wide text-bone">VANGUARD</span>
        <span className="block text-[8px] font-bold tracking-[0.25em] text-vanguard-cyan">PERFORMANCE LABS</span>
      </span>
    </div>
  );
}
