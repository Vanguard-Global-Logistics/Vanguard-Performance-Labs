"use client";
import Link from "next/link";
import { useState } from "react";
import { MessageSquare, X, Send } from "lucide-react";
import { NAV, DISCLAIMER } from "@/lib/content";
import { VanguardLogo, JessiePortrait } from "@/components/brand";

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-ink-1">
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <VanguardLogo />
            <p className="mt-4 max-w-xs text-sm text-muted">
              Leading the future of peptide education and clinic technology through science and veteran-led innovation.
            </p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-vanguard-gold/40 bg-vanguard-gold/10 px-3 py-1 text-[10px] font-bold tracking-wide text-vanguard-gold">
              ★ VETERAN OWNED · VETERAN RAN
            </div>
          </div>
          <FooterCol title="Explore" links={NAV.slice(1, 6)} />
          <FooterCol title="Business" links={NAV.slice(8, 12)} />
          <div>
            <div className="mb-3 text-xs font-bold uppercase tracking-widest text-bone">Legal</div>
            <ul className="space-y-2 text-sm text-muted">
              <li><Link href="/contact" className="hover:text-bone">Privacy Policy</Link></li>
              <li><Link href="/contact" className="hover:text-bone">Terms of Service</Link></li>
              <li><Link href="/contact" className="hover:text-bone">Medical Disclaimer</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-10 rounded-xl border border-vanguard-amber/30 bg-vanguard-amber/[0.06] px-4 py-3 text-xs leading-relaxed text-muted">
          {DISCLAIMER}
        </div>
        <div className="mt-6 text-xs text-muted">
          © {new Date().getFullYear()} Vanguard Global Logistics LLC, DBA Vanguard Performance Labs. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <div className="mb-3 text-xs font-bold uppercase tracking-widest text-bone">{title}</div>
      <ul className="space-y-2 text-sm text-muted">
        {links.map((l) => <li key={l.href}><Link href={l.href} className="hover:text-bone">{l.label}</Link></li>)}
      </ul>
    </div>
  );
}

// Jessie concierge dock — structured routing (not an autonomous medical agent).
// Refuses medical/dosing questions and routes to the right place.
const QUICK = [
  { label: "Explore research", href: "/education" },
  { label: "Book a Peptastic demo", href: "/peptastic" },
  { label: "Wholesale inquiry", href: "/wholesale" },
  { label: "Talk to sales", href: "/contact" },
];
const REFUSE = /(dose|dosing|how much|inject|reconstitut|mg|mcg|prescri|diagnos|treat my|cure|protocol for me)/i;

export function JessieDock() {
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("");
  const [reply, setReply] = useState<string | null>(null);

  function handle() {
    const q = msg.trim();
    if (!q) return;
    if (REFUSE.test(q)) {
      setReply("I can't help with dosing, diagnosis, or individual medical decisions — those belong with a licensed provider. But I can point you to our education library or connect you with the right team.");
    } else {
      setReply("Happy to help. Try one of the quick options below, or head to Contact and I'll route you to the right department.");
    }
    setMsg("");
  }

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Open Jessie, the Vanguard AI Concierge"
        className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-vg-grad px-4 py-3 text-sm font-semibold text-ink-0 shadow-[0_0_28px_rgba(59,107,255,0.5)]"
      >
        <MessageSquare size={18} /> Ask Jessie
      </button>

      {open && (
        <div className="fixed bottom-20 right-5 z-50 w-[340px] max-w-[calc(100vw-2.5rem)] overflow-hidden rounded-2xl border border-white/10 bg-ink-1/95 backdrop-blur-xl shadow-2xl">
          <div className="flex items-center gap-3 border-b border-white/10 bg-white/[0.03] px-4 py-3">
            <div className="h-10 w-10 overflow-hidden rounded-lg"><JessiePortrait size={40} /></div>
            <div className="flex-1">
              <div className="text-sm font-bold text-bone">Jessie</div>
              <div className="text-[10px] text-vanguard-teal">● Vanguard AI Concierge</div>
            </div>
            <button aria-label="Close" onClick={() => setOpen(false)} className="text-muted hover:text-bone"><X size={18} /></button>
          </div>
          <div className="px-4 py-3">
            <p className="text-sm text-bone">
              {reply ?? "I'm Jessie. I can guide you through Vanguard, our research education, and Peptastic. What are you looking for today?"}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {QUICK.map((q) => (
                <Link key={q.href} href={q.href} onClick={() => setOpen(false)}
                  className="rounded-full border border-vanguard-cyan/40 bg-vanguard-cyan/10 px-3 py-1.5 text-xs font-medium text-vanguard-cyan hover:bg-vanguard-cyan/20">
                  {q.label}
                </Link>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-2 border-t border-white/10 p-3">
            <input
              value={msg} onChange={(e) => setMsg(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handle()}
              placeholder="Ask Jessie…"
              className="flex-1 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-bone outline-none placeholder:text-muted"
            />
            <button onClick={handle} aria-label="Send" className="grid h-9 w-9 place-items-center rounded-lg bg-vg-grad text-ink-0"><Send size={16} /></button>
          </div>
          <p className="px-4 pb-3 text-[10px] leading-relaxed text-muted">
            Educational only. Jessie does not provide medical advice, diagnosis, or dosing.
          </p>
        </div>
      )}
    </>
  );
}
