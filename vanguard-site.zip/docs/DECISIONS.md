# DECISIONS — architecture & design log (append-only)

- 2026-07: Project split locked — Vanguard (this site), Peptastic (product), Throne/Jarvis (separate).
- 2026-07: Hero = blended composition (Image 2 hero on top + Image 1 dashboard below). Owner choice.
- 2026-07: Palette kept cyan/blue for now; purple/gold is a token-only swap in tailwind.config.ts +
  the --vg-grad token + GRAD constant when owner approves. No structural change required.
- 2026-07: Brand art shipped as SVG stand-ins (WingedVial/JessiePortrait/VanguardLogo) to keep the repo
  free of broken assets; swap for approved renders in /public later.
- 2026-07: Commerce = B2B inquiry only; no consumer peptide checkout. Server-controlled ordering.
- 2026-07: Consolidated all project instructions into docs/MASTER.md as the single source of truth,
  referenced at top of CLAUDE.md load order. On conflict, MASTER wins, then reconcile + log here.
- 2026-07: Visual matching is a BOUNDED loop (docs/VISUAL-MATCH-RUNBOOK.md): hard cap 5 passes, exit at
  score>=90 or <3-pt gain or only low-severity items; ends with REPORT.md + owner decision. Rejected the
  "iterate autonomously until pixel-perfect" framing — unreachable against a raster mockup and prone to
  regressing good work. Human makes the final taste call.
