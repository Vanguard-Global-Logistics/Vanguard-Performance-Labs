# ORDERING-WORKFLOWS — modular, provider-neutral, server-controlled

Types live in `types/index.ts`:

type RegulatoryStatus = "education_only" | "inquiry_only" | "wholesale_review" | "approved_for_sale" | "unavailable";
type OrderingMode     = "information_request" | "quote_only" | "po_only" | "invoice_only" | "approved_checkout";

`ACTIONS_BY_STATUS` maps status → allowed OrderingModes and is authoritative on the SERVER.
The product page reads it; the client form validates any ?action= against the allowed list.

Rules:
- Never infer availability/approval from artwork or copy.
- `approved_checkout` stays OFF until a provider + legal review (see COMPLIANCE-GUARDRAILS).
- A customer-entered PO/payment reference never marks anything paid; approval happens in admin workflow.
- Adding a future payment provider must NOT require redesigning the site — add it behind this layer.
