import type { Compound, RoleCard } from "@/types";

export const NAV = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About Vanguard" },
  { href: "/products", label: "Research Products" },
  { href: "/education", label: "Peptide Education Library" },
  { href: "/research", label: "Scientific Research" },
  { href: "/articles", label: "Articles" },
  { href: "/videos", label: "Video Library" },
  { href: "/peptastic", label: "Peptastic" },
  { href: "/professionals", label: "Medical Professionals" },
  { href: "/wholesale", label: "Wholesale" },
  { href: "/partnerships", label: "Partnerships" },
  { href: "/contact", label: "Contact" },
];

export const DISCLAIMER =
  "Educational only. Not medical advice, diagnosis, or treatment. For research and educational purposes. Consult a licensed medical professional.";

// Seed compounds — honest evidence levels. References are marked for editorial
// review; real PMIDs/DOIs are supplied by the owner's review process (never fabricated).
export const COMPOUNDS: Compound[] = [
  {
    slug: "bpc-157",
    name: "BPC-157",
    aliases: ["Body Protection Compound 157"],
    category: "Recovery",
    evidence: "limited",
    researchStatus: "Investigational — not approved for human use",
    overview:
      "A synthetic peptide derived from a sequence identified in gastric juice, studied in preclinical models for tissue and tendon repair.",
    mechanism:
      "Research explores effects on angiogenesis and growth-factor signaling in animal models; human mechanistic data is limited.",
    areasOfStudy: ["Tendon/ligament healing (animal)", "GI models (animal)"],
    safety: "Human safety is not established. Sold as research material without pharmaceutical manufacturing oversight.",
    faq: [
      { q: "Is BPC-157 approved?", a: "No. It is investigational and not approved for human use." },
      { q: "Is there human evidence?", a: "Controlled human trials are essentially absent; most data is animal or in vitro." },
    ],
    references: [{ label: "[Editorial review required]", note: "Insert verified PMID/DOI for representative preclinical study." }],
    lastReviewed: "2026-06-01",
    reviewStatus: "draft",
    regulatory: "education_only",
  },
  {
    slug: "tb-500",
    name: "TB-500",
    aliases: ["Thymosin beta-4 fragment"],
    category: "Recovery",
    evidence: "limited",
    researchStatus: "Investigational — not approved for human use",
    overview: "A synthetic fragment related to thymosin beta-4, studied in animal and laboratory models for tissue repair.",
    mechanism: "Preclinical research explores actin regulation and cell migration; human data is minimal.",
    areasOfStudy: ["Wound/tissue models (animal)"],
    safety: "Human safety not established. Banned in competitive sport.",
    faq: [{ q: "Is TB-500 studied in humans?", a: "Controlled human evidence is essentially absent." }],
    references: [{ label: "[Editorial review required]", note: "Insert verified reference." }],
    lastReviewed: "2026-06-01",
    reviewStatus: "draft",
    regulatory: "education_only",
  },
  {
    slug: "ghk-cu",
    name: "GHK-Cu",
    aliases: ["Copper peptide"],
    category: "Skin / Hair",
    evidence: "moderate",
    researchStatus: "Cosmetic and research use",
    overview: "A copper-binding tripeptide studied primarily in topical/cosmetic contexts for skin.",
    mechanism: "Research explores roles in skin remodeling and antioxidant signaling; strongest data is topical.",
    areasOfStudy: ["Topical skin studies (human)", "Wound models (animal)"],
    safety: "Topical cosmetic use is common; systemic/injected use is less studied.",
    faq: [{ q: "Is GHK-Cu in skincare?", a: "Yes, copper peptides appear in many topical cosmetic products." }],
    references: [{ label: "[Editorial review required]", note: "Insert verified reference." }],
    lastReviewed: "2026-06-01",
    reviewStatus: "draft",
    regulatory: "education_only",
  },
  {
    slug: "cjc-1295",
    name: "CJC-1295",
    aliases: ["GHRH analogue"],
    category: "Growth",
    evidence: "limited",
    researchStatus: "Investigational",
    overview: "A growth-hormone-releasing hormone analogue studied for its effect on GH and IGF-1.",
    mechanism: "Stimulates GH secretion in small studies; long-term outcomes and safety in healthy adults are unknown.",
    areasOfStudy: ["GH/IGF-1 response (small human studies)"],
    safety: "Long-term safety unknown. Often discussed alongside ipamorelin.",
    faq: [{ q: "Does it raise GH?", a: "Small studies show GH/IGF-1 increases; outcome data is limited." }],
    references: [{ label: "[Editorial review required]", note: "Insert verified reference." }],
    lastReviewed: "2026-06-01",
    reviewStatus: "draft",
    regulatory: "education_only",
  },
  {
    slug: "ipamorelin",
    name: "Ipamorelin",
    aliases: ["GH secretagogue"],
    category: "Growth",
    evidence: "moderate",
    researchStatus: "Investigational",
    overview: "A growth-hormone secretagogue studied for its selective GH-releasing effect.",
    mechanism: "Acts on the ghrelin/GH secretagogue receptor to raise GH in studies; long-term data is limited.",
    areasOfStudy: ["GH response (human studies)"],
    safety: "Long-term outcome and safety data in healthy adults is limited.",
    faq: [{ q: "Is it selective?", a: "It is described as a relatively selective GH secretagogue in studies." }],
    references: [{ label: "[Editorial review required]", note: "Insert verified reference." }],
    lastReviewed: "2026-06-01",
    reviewStatus: "draft",
    regulatory: "education_only",
  },
  {
    slug: "retatrutide",
    name: "Retatrutide",
    aliases: ["Triple agonist (GLP-1/GIP/glucagon)"],
    category: "Metabolic",
    evidence: "moderate",
    researchStatus: "Investigational — Phase 3 (not approved; anticipated ~2027)",
    overview:
      "An investigational triple-agonist studied in large trials for weight and metabolic outcomes. Not FDA-approved and has no legal compounding pathway.",
    mechanism: "Agonism at GLP-1, GIP, and glucagon receptors; studied in the manufacturer's Phase 3 program.",
    areasOfStudy: ["Weight reduction (Phase 3 human trials)", "Metabolic endpoints"],
    safety: "Investigational. Efficacy signals in trials are strong, but it is not approved and not legally available outside trials.",
    faq: [
      { q: "Can I buy approved retatrutide?", a: "No. It is investigational; there is no approved or legal compounded version." },
    ],
    references: [{ label: "[Editorial review required]", note: "Insert verified trial citation (e.g., published Phase 3 results)." }],
    lastReviewed: "2026-06-01",
    reviewStatus: "draft",
    regulatory: "education_only",
  },
];

export const PEPTASTIC_FEATURES = [
  { title: "AI Concierge", desc: "Jessie guides patients and staff, answers FAQs, and routes work." },
  { title: "Clinic CRM", desc: "Unified patient records, engagement history, and pipelines." },
  { title: "Scheduling", desc: "Appointments, reminders, and provider calendars." },
  { title: "Memberships", desc: "Recurring plans, perks, and retention tracking." },
  { title: "Inventory", desc: "Stock levels, low-supply alerts, and reorder signals." },
  { title: "Analytics", desc: "Revenue, conversion, and operational KPIs at a glance." },
  { title: "Marketing", desc: "Campaigns, follow-ups, and automated outreach." },
  { title: "Automation", desc: "Workflow suggestions that reduce manual busywork." },
  { title: "Staff Management", desc: "Roles, coverage, cross-training, and knowledge capture." },
  { title: "Reporting", desc: "Executive dashboards and exportable reports." },
];

export const ROLE_CARDS: RoleCard[] = [
  { role: "Owner", blurb: "See the whole business — revenue, coverage, and AI-surfaced opportunities — in one command view." },
  { role: "Provider", blurb: "Spend less time on admin; the assistant preps context and handles follow-ups." },
  { role: "Nurse", blurb: "Fast access to approved workflows and consistent, up-to-date operational guidance." },
  { role: "Front Desk", blurb: "Scheduling, reminders, and answers to common questions, handled with less friction." },
  { role: "Inventory", blurb: "Low-supply alerts and reorder signals so nothing critical runs out." },
  { role: "Billing", blurb: "Cleaner records, fewer errors, and clear status on quotes and invoices." },
  { role: "Executive", blurb: "Board-ready reporting and trends without waiting on manual spreadsheets." },
];

export const INTEGRATIONS = [
  "QuickBooks", "Authorize.net", "Stripe", "Twilio",
  "Google Workspace", "Microsoft 365", "Zoom", "Future APIs",
];
