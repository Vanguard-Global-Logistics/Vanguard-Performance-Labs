import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { 0: "#05070F", 1: "#0A0E1C", 2: "#111631" },
        vanguard: {
          cyan: "#29D9FF",
          blue: "#3B6BFF",
          violet: "#8B5CF6",
          teal: "#2ED9B8",
          amber: "#FFB830",
          rose: "#FF5D8F",
          gold: "#C8A24B",
        },
        bone: "#EAF0FF",
        muted: "#8A93C2",
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        "vg-grad": "linear-gradient(135deg,#29D9FF 0%,#3B6BFF 50%,#8B5CF6 100%)",
      },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-10px)" } },
        pulseRing: { "0%,100%": { opacity: "0.5", transform: "scale(1)" }, "50%": { opacity: "1", transform: "scale(1.05)" } },
        rise: { from: { opacity: "0", transform: "translateY(16px)" }, to: { opacity: "1", transform: "none" } },
        wave: { "0%,100%": { transform: "scaleY(0.35)" }, "50%": { transform: "scaleY(1)" } },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        pulseRing: "pulseRing 3s ease-in-out infinite",
        rise: "rise .6s ease both",
        wave: "wave 1s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
export default config;
